<?php
$host = 'localhost'; // адрес сервера 
$database = 'restaurant'; // имя базы данных
$user = 'root'; // имя пользователя
$password = 'nastea'; // пароль
?>