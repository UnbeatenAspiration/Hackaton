<?php

$name = $_POST ['name'];
$mail = $_POST ['mail'];
$theme = $_POST ['theme'];
$message = $_POST ['message'];

$mail_form = 'Stucalova Anastasia';
$mail_subject = 'Новое сообщение от YRestaurant';
$mail_body = "Name: $name.\n".
"Mail: $mail.\n".
"Theme: $theme.\n".
"Message: $message.\n";

$to = "minnati69@gmail.com";
$subject = "My subject";
$txt = "Сообщение принятно";
$headers = "From:  webmaster@example.com \r\n".
"CC: minnati69@gmail.com";

mail($to,$mail_subject,$mail_body,$headers);

header('Location: http://localhost/diplom/contact.html');
exit;
?>