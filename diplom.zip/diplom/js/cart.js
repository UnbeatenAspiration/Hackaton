$(document).ready(function(){
    $(document).on('click','.add-to-cart', (e) => {
        e.preventDefault();

        let $this = $(e.currentTarget);


        let product = {};
        try {
            product.price = $this.closest('div').find('.price').text();
            product.title = $this.closest('div').find('h3 > a')[0].innerHTML;
            product.image = $this.closest('div').siblings('a')[0].style.backgroundImage;

            if(localStorage.getItem('cart')){
                let arr = [...JSON.parse(localStorage.getItem('cart'))];

                if(arr.filter(arr => arr.title === product.title).length){
                    arr.pop()
                    $this.text('Удалено из корзины');
                }else {
                    arr.push(product)
                    $this.text('Добавлено в корзину');
                }

                localStorage.setItem('cart', JSON.stringify(arr));
            }else{
                localStorage.setItem('cart', JSON.stringify([product]));
            }
        } catch (e) {
            console.log(e.message);
            try {
                let product = {};

                product.price = $this.closest('p').find('span').text();
                product.title = $this.closest('div').find('h3')[0].innerHTML;

                product.image = $this.closest('div').siblings('.img')[0].style.backgroundImage;

                if(localStorage.getItem('cart')){
                    let arr = [...JSON.parse(localStorage.getItem('cart'))];

                    if(arr.filter(arr => arr.title === product.title).length){
                        arr.pop()
                        $this.text('Удалено из корзины');
                    }else {
                        arr.push(product)
                        $this.text('Добавлено в корзину');
                    }

                    localStorage.setItem('cart', JSON.stringify(arr));
                }else{
                    localStorage.setItem('cart', JSON.stringify([product]));
                }
            } catch (e) {
                    console.log(e.message)
            }
        }

    })
    getInitialProducts();
})

function getInitialProducts(){
    let tbody = $('#cart-products'),
        total = 0;

    if(!tbody.length){
        return
    }

    try {
        let products = JSON.parse(localStorage.getItem('cart'));
        products.map((pr, index) => {
            let prText = `<tr>
                <td> <img src="${pr.image.slice(5, -2)}" width="140" height="151" alt="drink-14"></td>
                <td>${pr.title}</td>
                <td>${pr.price}</td>`

            total += parseInt(pr.price.slice(0, pr.price.indexOf(' ')));

            if(index === products.length - 1){
                    prText += `<th>Итого ${total} лей</th>`
            };

            prText += '</tr>';

            return (
                tbody.append(prText)
            )
        })
    } catch (e) {
        console.log(e.message)
    }
}
