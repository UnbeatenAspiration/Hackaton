function SendEmail(e){
    e.preventDefault()
    var name = $('#name').val();
    var mail = $('#mail').val();
    var theme = $('#theme').val();
    var message = $('#message').val();
    if (name!= '' && mail!= '' && theme!= '' && message!= ''){
    if (isEmpty(cart)){
    }
    else {
    alert('Поля не заполнены')
    }
    }
    else {
    alert('Заполните поля');
    }
    }
    
    $('.btn btn-primary py-3 px-5') .on('click', SendEmail);