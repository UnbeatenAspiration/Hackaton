document.addEventListener("DOMContentLoaded", main)
function main() {
    console.log("hello, world!");
    fillStorage();
 
}
 
var massiveamount = [
    { id: 1, name: 'cpu', price: 5000, amount: 3 },
    { id: 2, name: 'flash', price: 500, amount: 50 },
    { id: 3, name: 'monitor', price: 8000, amount: 15 },
    { id: 4, name: 'mouse', price: 300, amount: 500 },
    { id: 5, name: 'keyboard', price: 100, amount: 200 }
]
 
function fillStorage() {
    massiveamount.forEach(function (currentValue) {
        console.log(currentValue)
 
    })
    var tbody = document.getElementById('left_table')
    for (var i = 0; i < massiveamount.length; i++) {
        var tr = document.createElement('tr');
        tr.setAttribute("id", "left" + massiveamount[i].id);
        tr.setAttribute("dbId", massiveamount[i].id);
        tr.innerHTML = '<td>' + massiveamount[i].name + '</td>' +
            '<td>' + massiveamount[i].price + '</td>' +
            '<td>' + massiveamount[i].amount + '</td>';
        tr.addEventListener('click', addToBascket)
        tbody.appendChild(tr);
    }
}
 
var massiveamount_sale = [
    { right_id: 1, name: 'cpu', price: 5000, amount: 0 },
    { right_id: 2, name: 'flash', price: 500, amount: 0 },
    { right_id: 3, name: 'monitor', price: 8000, amount: 0 },
    { right_id: 4, name: 'mouse', price: 300, amount: 0 },
    { right_id: 5, name: 'keyboard', price: 100, amount: 0 }
]
 
// addToBascket добавляет выбранный элемент в корзину
function addToBascket(e) {
    console.log(e.target.parentNode);
    let clickedId = e.target.parentNode.getAttribute("dbid", 'right_table');
    /*
    var tbody = document.getElementById('right_table')
    var tr1 = document.createElement('tr');
    tbody.appendChild(tr1);
    if (massiveamount_sale[0].amount == 0) { massiveamount_sale[0].amount = 1 }
    else {
        massiveamount_sale[0].amount += 1;
    }
    tr1.innerHTML =
        '<td>' + massiveamount_sale[0].right_id + '</td>' +
        '<td>' + massiveamount_sale[0].name + '</td>' +
        '<td>' + massiveamount_sale[0].price + '</td>' +
        '<td>' + massiveamount_sale[0].amount + '</td>';
    tbody.appendChild(tr1);
    */
}